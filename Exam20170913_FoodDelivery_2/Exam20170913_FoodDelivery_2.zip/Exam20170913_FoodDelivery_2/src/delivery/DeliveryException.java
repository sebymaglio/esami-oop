package delivery;

public class DeliveryException extends Exception {
    private static final long serialVersionUID = 1L;

    public DeliveryException() {
    }

    public DeliveryException(String message) {
        super(message);
    }

 }
