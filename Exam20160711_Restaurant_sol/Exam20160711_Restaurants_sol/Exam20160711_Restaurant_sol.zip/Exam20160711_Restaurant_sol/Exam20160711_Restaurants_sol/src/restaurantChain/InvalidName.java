package restaurantChain;

public class InvalidName extends Exception {
    private static final long serialVersionUID = 1L;

}
